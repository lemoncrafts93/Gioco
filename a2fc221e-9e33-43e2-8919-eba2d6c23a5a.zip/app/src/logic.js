export const meta = {
  game: "Neon City Getaway",
  minPlayers: 1,
  maxPlayers: 1,
};

export function setup(players) {
  return {
    player: players[0] ?? null,
    score: 0,
    checkpoints: 0,
    crashes: 0,
    escaped: false,
    busted: false,
  };
}

export function validateAction(state, playerId, action) {
  if (state.escaped || state.busted) return { ok: false, error: "game over" };
  if (state.player !== playerId) return { ok: false, error: "not your seat" };
  if (!action || typeof action !== "object") return { ok: false, error: "invalid action" };
  if (action.kind === "checkpoint") {
    if (!Number.isInteger(action.index) || action.index < 1 || action.index > 99) return { ok: false, error: "invalid checkpoint" };
    if (action.index !== state.checkpoints + 1) return { ok: false, error: "checkpoint out of order" };
    return { ok: true };
  }
  if (action.kind === "score") {
    if (!Number.isInteger(action.points) || action.points < 0 || action.points > 250) return { ok: false, error: "invalid score" };
    return { ok: true };
  }
  if (action.kind === "crash") return { ok: true };
  if (action.kind === "escape") return state.checkpoints >= 8 ? { ok: true } : { ok: false, error: "route incomplete" };
  if (action.kind === "busted") return { ok: true };
  return { ok: false, error: "unknown action" };
}

export function applyAction(state, playerId, action) {
  if (action.kind === "checkpoint") {
    return { ...state, checkpoints: action.index, score: state.score + 500 + action.index * 25 };
  }
  if (action.kind === "score") return { ...state, score: state.score + action.points };
  if (action.kind === "crash") return { ...state, crashes: state.crashes + 1, score: Math.max(0, state.score - 120) };
  if (action.kind === "escape") return { ...state, escaped: true, score: state.score + 1500 };
  if (action.kind === "busted") return { ...state, busted: true };
  return state;
}

export function isGameOver(state) {
  if (state.escaped) return { over: true, winner: state.player, reason: "escaped" };
  if (state.busted) return { over: true, winner: null, reason: "busted" };
  return { over: false };
}

export function viewFor(state, playerId) {
  return {
    score: state.score,
    checkpoints: state.checkpoints,
    crashes: state.crashes,
    escaped: state.escaped,
    busted: state.busted,
    you: state.player === playerId,
  };
}
