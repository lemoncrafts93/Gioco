const room = new URLSearchParams(location.search).get("room") || "main";
const $ = (s) => document.querySelector(s);
const canvas = $("#game");
const ctx = canvas.getContext("2d");
const scoreEl = $("#score");
const cpEl = $("#checkpoint");
const heatEl = $("#heat");
const statusEl = $("#status");
const helpEl = $("#help");
const resultEl = $("#result");
const resetEl = $("#reset");

let socket = null, retry = 0, serverView = null;
let keys = new Set();
let last = performance.now();
let syncTimer = 0;
let roadScroll = 0;
let distance = 0;
let scoreLocal = 0;
let checkpointLocal = 0;
let crashesLocal = 0;
let policeHeat = 0.22;
let busted = false;
let escaped = false;
let lane = 0;
let laneTarget = 0;
let playerX = 0;
let speed = 0.68;
let spawnClock = 0;
const traffic = [];
const police = [];
const particles = [];
const img = {hero:new Image(), police:new Image(), traffic:new Image(), city:new Image(), street:new Image()};
img.hero.src="/assets/hero.png"; img.police.src="/assets/police.png"; img.traffic.src="/assets/traffic.png"; img.city.src="/assets/city.png"; img.street.src="/assets/street.png";
const checkpoints = [700,1450,2250,3150,4100,5100,6250,7500];
const laneXs = [-0.72,-0.36,0,0.36,0.72];
const road = {left:0.12,right:0.88};

function id(){ const k="hf:game:playerId"; let v=localStorage.getItem(k); if(!v){v=crypto.randomUUID();localStorage.setItem(k,v)} return v; }
function send(action){ if(socket?.readyState===1) socket.send(JSON.stringify({type:"action",action})); }
function connect(){
  const p=location.protocol==="https:"?"wss:":"ws:";
  socket=new WebSocket(`${p}//${location.host}/ws/${encodeURIComponent(room)}`);
  socket.onopen=()=>{retry=0; statusEl.textContent="PURSUIT LIVE"; socket.send(JSON.stringify({type:"join",playerId:id()}));};
  socket.onmessage=(e)=>{ if(e.data==="__pong")return; try{const m=JSON.parse(e.data); if(m.type==="state"){serverView=m.view||null; renderHud(m);} }catch{} };
  socket.onclose=()=>{retry=Math.min(retry+1,6);statusEl.textContent="RECONNECTING…";setTimeout(connect,Math.min(6000,500*2**(retry-1)));};
}
function renderHud(m){
  if(!m.view)return;
  scoreEl.textContent=(m.view.score??scoreLocal).toLocaleString();
  cpEl.textContent=`${m.view.checkpoints??checkpointLocal}/8`;
  if(m.status==="over"){resultEl.hidden=false;resultEl.textContent=m.view.escaped?"ESCAPED — CITY LOST YOU":"BUSTED — HIT RESTART";}
}
function resize(){const d=devicePixelRatio||1,w=innerWidth,h=innerHeight;canvas.width=w*d;canvas.height=h*d;canvas.style.width=w+"px";canvas.style.height=h+"px";ctx.setTransform(d,0,0,d,0,0)}
addEventListener("resize",resize); resize();
addEventListener("keydown",e=>{if(["ArrowLeft","ArrowRight","KeyA","KeyD","KeyW","ArrowUp","Space","KeyR"].includes(e.code))e.preventDefault();keys.add(e.code);if(e.code==="KeyR"&&resultEl.hidden===false)reset();});
addEventListener("keyup",e=>keys.delete(e.code));
resetEl.onclick=reset;
function reset(){ location.href=location.pathname+"?room="+encodeURIComponent(room)+"&new="+Date.now(); }

function roadY(t){return canvas.height/2 + t*t*canvas.height*.75}
function projectLane(x,t){const y=roadY(t); const spread=(canvas.width*(.12+.76*t)); return canvas.width/2+x*spread/2;}
function spawnTraffic(){const l=laneXs[Math.floor(Math.random()*laneXs.length)];traffic.push({lane:l,t:0.03,v:.08+Math.random()*.08,type:Math.random()<.2?1:0});}
function spawnPolice(){const l=laneXs[Math.floor(Math.random()*laneXs.length)];police.push({lane:l,t:.04,v:.075+policeHeat*.055});}
function burst(x,y,n=8){for(let i=0;i<n;i++)particles.push({x,y,vx:(Math.random()-.5)*140,vy:(Math.random()-.5)*140,a:1});}
function rectCar(x,y,w,h,kind){const im=kind===2?img.traffic:kind===1?img.police:img.hero;if(im.complete&&im.naturalWidth){ctx.save();ctx.translate(x,y);ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();return}ctx.save();ctx.translate(x,y);ctx.fillStyle=kind===2?"#d7e9ff":kind===1?"#2f77db":"#f04449";ctx.strokeStyle="#081b3d";ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,w*.22);ctx.fill();ctx.stroke();ctx.restore()}
function draw(){
  const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
  const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,"#07152d");g.addColorStop(.5,"#102451");g.addColorStop(1,"#030814");ctx.fillStyle=g;ctx.fillRect(0,0,w,h);if(img.city.complete){ctx.globalAlpha=.72;ctx.drawImage(img.city,0,0,w,h*.62);ctx.globalAlpha=1}
  // city blocks
  for(let i=0;i<16;i++){const bw=30+(i*17)%70;const bh=60+(i*43)%150;const x=(i/16)*w;ctx.fillStyle=i%3?"#101c39":"#18284a";ctx.fillRect(x,h*.49-bh,bw,bh);ctx.fillStyle=i%2?"#37c7ff":"#ff5b7a";for(let r=0;r<4;r++)for(let c=0;c<2;c++)if((r+c+i)%3===0)ctx.fillRect(x+8+c*14,h*.49-bh+10+r*22,6,8)}
  // road
  ctx.save();ctx.beginPath();ctx.moveTo(w*.16,h);ctx.lineTo(w*.39,h*.48);ctx.lineTo(w*.61,h*.48);ctx.lineTo(w*.84,h);ctx.closePath();ctx.clip();if(img.street.complete){const pattern=ctx.createPattern(img.street,"repeat");ctx.fillStyle=pattern;ctx.globalAlpha=.48;ctx.fillRect(0,h*.47,w,h*.55);ctx.globalAlpha=1}ctx.fillStyle="#101522aa";ctx.fillRect(0,h*.47,w,h*.55);ctx.restore();
  ctx.strokeStyle="#34415b";ctx.lineWidth=2;for(let l=-1;l<=1;l+=.5){ctx.beginPath();ctx.moveTo(w/2+l*w*.12,h);ctx.lineTo(w/2+l*w*.02,h*.48);ctx.stroke()}
  ctx.strokeStyle="#ffd84d";ctx.lineWidth=5;ctx.setLineDash([24,22]);ctx.lineDashOffset=roadScroll;ctx.beginPath();ctx.moveTo(w*.18,h);ctx.lineTo(w*.4,h*.48);ctx.moveTo(w*.82,h);ctx.lineTo(w*.6,h*.48);ctx.stroke();ctx.setLineDash([]);
  // checkpoint gate
  const next=checkpoints[checkpointLocal];const prog=Math.max(0,Math.min(1,(distance-(next-220))/440));if(!escaped&&checkpointLocal<8&&prog>0){const gy=h*.52;ctx.strokeStyle="#32e7ff";ctx.lineWidth=8;ctx.strokeRect(w*.32,gy-32,w*.36,64);ctx.fillStyle="#8ef6ff";ctx.font="700 12px system-ui";ctx.textAlign="center";ctx.fillText(`CHECKPOINT ${checkpointLocal+1}`,w/2,gy+5)}
  traffic.forEach(o=>{const y=roadY(o.t),x=projectLane(o.lane,o.t);const s=12+o.t*28;rectCar(x,y,s,s*1.65,o.type)});
  police.forEach(o=>{const y=roadY(o.t),x=projectLane(o.lane,o.t);const s=13+o.t*34;rectCar(x,y,s,s*1.65,1)});
  particles.forEach(p=>{ctx.globalAlpha=p.a;ctx.fillStyle="#ffcf5a";ctx.fillRect(p.x,p.y,3,3);ctx.globalAlpha=1});
  const px=projectLane(playerX,.98),py=h*.84;rectCar(px,py,42,70,0);
  ctx.fillStyle="#fefefe";ctx.font="700 10px system-ui";ctx.textAlign="center";ctx.fillText("YOU",px,py+48);
}
function collision(o){return o.t>.82 && Math.abs(o.lane-playerX)<.18}
function update(dt){
  const steer=(keys.has("ArrowLeft")||keys.has("KeyA")?-1:0)+(keys.has("ArrowRight")||keys.has("KeyD")?1:0);
  laneTarget=Math.max(-.78,Math.min(.78,laneTarget+steer*dt*1.65));playerX+=(laneTarget-playerX)*Math.min(1,dt*7);
  const throttle=keys.has("ArrowUp")||keys.has("KeyW");speed+=(throttle?.32:-.12)*dt;speed=Math.max(.36,Math.min(1.05,speed));
  distance+=speed*dt*360;roadScroll+=speed*dt*180;
  spawnClock-=dt;if(spawnClock<=0){spawnTraffic();if(police.length<3&&policeHeat>.3)spawnPolice();spawnClock=.42+Math.random()*.55}
  traffic.forEach(o=>o.t+=o.v*dt*speed*2.2);police.forEach(o=>{o.t+=(o.v+Math.max(0,(.9-o.t))*.07)*dt*speed*2.1;o.lane+=(playerX-o.lane)*dt*(.18+policeHeat*.4)});
  for(let i=traffic.length-1;i>=0;i--){const o=traffic[i];if(collision(o)){traffic.splice(i,1);crashesLocal++;policeHeat=Math.min(1,policeHeat+.12);scoreLocal=Math.max(0,scoreLocal-120);burst(projectLane(o.lane,o.t),roadY(o.t),14);send({kind:"crash"})}else if(o.t>1.08){traffic.splice(i,1);scoreLocal+=25;send({kind:"score",points:25})}}
  for(let i=police.length-1;i>=0;i--){const o=police[i];if(collision(o)&&o.t>.9){policeHeat=Math.min(1,policeHeat+.2);burst(projectLane(o.lane,o.t),roadY(o.t),18);police.splice(i,1);crashesLocal++;}else if(o.t>1.05){police.splice(i,1)}}
  const next=checkpoints[checkpointLocal];if(distance>=next){checkpointLocal++;policeHeat=Math.max(.2,policeHeat-.08);scoreLocal+=500+checkpointLocal*25;send({kind:"checkpoint",index:checkpointLocal});if(checkpointLocal>=8){escaped=true;send({kind:"escape"});}}
  policeHeat=Math.min(1,policeHeat+dt*.006);if(policeHeat>0.98&&police.length>=3){const near=police.some(o=>o.t>.78&&Math.abs(o.lane-playerX)<.2);if(near){busted=true;send({kind:"busted"})}}
  particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.a-=dt*2});for(let i=particles.length-1;i>=0;i--)if(particles[i].a<=0)particles.splice(i,1);
  syncTimer+=dt;if(syncTimer>1){syncTimer=0;scoreEl.textContent=scoreLocal.toLocaleString();cpEl.textContent=`${checkpointLocal}/8`;heatEl.style.setProperty("--heat",policeHeat);}
}
function frame(now){const dt=Math.min(.033,(now-last)/1000);last=now;if(!busted&&!escaped)update(dt);draw();requestAnimationFrame(frame)}
connect();requestAnimationFrame(frame);
